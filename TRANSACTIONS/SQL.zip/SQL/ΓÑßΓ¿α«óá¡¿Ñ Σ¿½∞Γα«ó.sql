select *
  from table(Z_SB_PL_FILTER.EXEC_FILTER('p1=-1|p2=%|p3=-1',
                                        'Frm_Filter.730873887'));
