select *
  from AU_ACTION t
 where ctable = 'UPS'
   and ID_ANUM = 'OV_PLAT.SET_PR_RUB_4'
