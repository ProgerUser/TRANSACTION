select terminal, CHECKSINCOMING
  from Z_SB_TRANSACT_AMRA_DBT t
 where CHECKSINCOMING is not null
   and CHECKSINCOMING like '%SB%'
   and CHECKSINCOMING not like '%' || t.terminal || '%'
   and terminal like 'SB%'
