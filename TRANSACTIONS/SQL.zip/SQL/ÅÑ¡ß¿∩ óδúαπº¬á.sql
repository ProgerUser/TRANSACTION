with dat as
 (select COLUMN6,
         substr(COLUMN6, 13, 1) otd,
         (select acc.IACCOTD from acc where caccacc = COLUMN6) caccacc,
         (select IPLAAGRID from v_PLA where v_PLA.CACCACC = COLUMN6) grid,
         (select IPLCID from v_PLA where v_PLA.CACCACC = COLUMN6) plcnum
    from table(lob2table.separatedcolumns((select t.cl_
                                            from Z_PENS_CL t
                                           where t.type_ = 'FILE'
                                             and t.id_ = 19114),
                                          chr(10),
                                          '|',
                                          '')) t
   where substr(COLUMN6, 13, 1) = 0
   order by case
              when (select IPLCID from v_PLA where v_PLA.CACCACC = COLUMN6) = 8601 then
               1
              when (select IPLCID from v_PLA where v_PLA.CACCACC = COLUMN6) = 7816 then
               2
            end),
dat_rn as
 (select rownum rn, t.* from dat t)
select *
  from dat_rn
 where rn between ((select count(*) from dat) / 3) and
       (select count(*) from dat)

/*
9748

1) 3249
2) 3249
3) 3249

1) rn between 3250 and 9748
etc.
*/
