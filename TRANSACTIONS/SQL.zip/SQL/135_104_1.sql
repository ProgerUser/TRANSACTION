Select B.ncdvagrid cArg,
       cdterms.get_DogACC(B.nCDVagrid, 6) cAcc,
       B.ICDVCLIENT iCus,
       F.idSMR idSMR,
       F.iSMRfil iFil,
       substr(cdterms.get_DogACC(B.nCDVagrid, 6), 1, 5) BS2,
       RATES.Cur_Rate_New(B.CCDVCURISO, (to_date(&D, 'dd.mm.yyyy') - 1)) *
       nvl(CDBALANCE.get_CurSaldo(B.NCDVAGRID,
                                  6,
                                  null,
                                  null,
                                  (to_date(&D, 'dd.mm.yyyy') - 1)),
           0) mRePA, --������������ ��������
       0 mRePpA
  from Fil_On2 F, cdv B, cda A
 Where A.idSmr = F.idSMR
   and F.iSMRfil = Decode(&vFil, -1, F.iSMRfil, &vFil)
   and B.ncdvagrid = A.ncdaagrid
   and (to_date(&D, 'dd.mm.yyyy') - 1) -
       greatest(B.DCDVENDDATE,
                (select nvl(max(DCDEDATE),
                            to_date('01.01.1900', 'dd.mm.yyyy'))
                   from cde e
                  where e.NCDEAGRID = a.NCDAAGRID
                    and e.icdetype in (2, 3, 12, 13, 72, 113, 172))) > 1095
   and substr(cdterms.get_DogACC(B.nCDVagrid, 6), 1, 5) != 45918 --��������� ������.����

union all

Select B.ncdvagrid cArg,
       cdterms.get_DogACC(B.nCDVagrid, 101) cAcc,
       B.ICDVCLIENT iCus,
       F.idSMR idSMR,
       F.iSMRfil iFil,
       substr(cdterms.get_DogACC(B.nCDVagrid, 101), 1, 5) BS2,
       0 mRePA,
       RATES.Cur_Rate_New(B.CCDVCURISO, (to_date(&D, 'dd.mm.yyyy') - 1)) *
       nvl(CDBALANCE.get_CurSaldo(B.NCDVAGRID,
                                  101,
                                  null,
                                  null,
                                  (to_date(&D, 'dd.mm.yyyy') - 1)),
           0) mRePpA --�������� �� ������������ ��������
  from Fil_On2 F, cdv B, cda A
 Where A.idSmr = F.idSMR
   and F.iSMRfil = Decode(&vFil, -1, F.iSMRfil, &vFil)
   and B.ncdvagrid = A.ncdaagrid
   and (to_date(&D, 'dd.mm.yyyy') - 1) -
       greatest(B.DCDVENDDATE,
                (select nvl(max(DCDEDATE),
                            to_date('01.01.1900', 'dd.mm.yyyy'))
                   from cde e
                  where e.NCDEAGRID = a.NCDAAGRID
                    and e.icdetype in (2, 3, 12, 13, 72, 113, 172))) > 1095
   and substr(cdterms.get_DogACC(B.nCDVagrid, 101), 1, 5) != 45918; --��������� ������.����
