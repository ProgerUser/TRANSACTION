select * from UPS t
where cupspref like 'OV_PLAT.SET_PR_RUB_4'
