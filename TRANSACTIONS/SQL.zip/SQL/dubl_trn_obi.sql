select * from (
select count(*) over(partition by CTRNACCD, CTRNACCC, MTRNRSUM, CTRNPURP) cnt,
       ROW_NUMBER() over(partition by CTRNACCD, CTRNACCC, MTRNRSUM, CTRNPURP order by CTRNACCD, CTRNACCC, MTRNRSUM, CTRNPURP) rn,
       t.*
  from trn t
 where trunc(DTRNTRAN) = '27.02.2020'
)where cnt >1
