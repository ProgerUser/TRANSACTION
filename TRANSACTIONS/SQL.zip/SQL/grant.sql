create public synonym z_sb_pl_filter_s for xxi.z_sb_pl_filter_s

grant execute listagg_clob

GRANT privileges ON object TO user;

GRANT select ON z_sb_pl_filter_s TO odb;
