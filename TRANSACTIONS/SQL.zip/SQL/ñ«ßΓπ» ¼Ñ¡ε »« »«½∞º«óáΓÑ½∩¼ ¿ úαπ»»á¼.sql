/*SELECT GROUP_ID
  FROM (select '' va,
               MNC.iMNCmnb menu_id,
               ODB_Group_Usr.grp_id group_id,
               ODB_Group_Usr.grp_name group_name,
               '' status
          from MNC, ODB_Group_Usr
         where ODB_Group_Usr.grp_id = MNC.idMNCgrp
           and not exists
         (select null
                  from MNC_Spool
                 where MNC_Spool.iMNCmnb = MNC.iMNCmnb
                   and MNC_Spool.idMNCgrp = MNC.idMNCgrp)
        union all
        select Decode(NVL(MNC_Spool.eid, -1), -1, 'Spool', 'Register') va,
               MNC_Spool.iMNCmnb menu_id,
               ODB_Group_Usr.grp_id group_id,
               ODB_Group_Usr.grp_name group_name,
               Decode(NVL(MNC_Spool.eid, -1),
                      -1,
                      '������ ������������ � �����������',
                      '������ ����������������') status
          from MNC_Spool, ODB_Group_Usr
         where MNC_Spool.grant_revoke = 'G'
           and ODB_Group_Usr.grp_id = MNC_Spool.idMNCgrp)
 WHERE menu_id in
       (SELECT IMNBID
          FROM MNB
         where mnb.cmnbname = '�� �� ������������� ���������');

SELECT * FROM MNA;

SELECT IMNBID
  FROM MNB
 where mnb.cmnbname = '�� �� ������������� ���������';

SELECT *
  FROM (select '' va,
               ODB_Grp_Member.grp_id,
               USR.iUSRid,
               USR.cUSRlogname,
               USR.cUSRname,
               USR.dUSRfire
          from ODB_Grp_Member, USR
         where not exists
         (select null
                  from ODB_Grp_Member_Spool
                 where ODB_Grp_Member_Spool.iUSRid = ODB_Grp_Member.iUSRid
                   and ODB_Grp_Member_Spool.grp_id = ODB_Grp_Member.grp_id)
           and USR.iUSRid = ODB_Grp_Member.iUSRid
        union all
        select Decode(NVL(ODB_Grp_Member_Spool.eid, -1),
                      -1,
                      'Spool',
                      'Register') va,
               ODB_Grp_Member_Spool.grp_id,
               USR.iUSRid,
               USR.cUSRlogname,
               USR.cUSRname,
               USR.dUSRfire
          from ODB_Grp_Member_Spool, USR
         where ODB_Grp_Member_Spool.grant_revoke = 'G'
           and USR.iUSRid = ODB_Grp_Member_Spool.iUSRid);

SELECT * FROM ODB_GROUP_USR WHERE GRP_NAME in ();

SELECT *
  FROM (select '' va,
               ODB_Grp_Member.grp_id,
               USR.iUSRid,
               USR.cUSRlogname,
               USR.cUSRname,
               USR.dUSRfire
          from ODB_Grp_Member, USR
         where not exists
         (select null
                  from ODB_Grp_Member_Spool
                 where ODB_Grp_Member_Spool.iUSRid = ODB_Grp_Member.iUSRid
                   and ODB_Grp_Member_Spool.grp_id = ODB_Grp_Member.grp_id)
           and USR.iUSRid = ODB_Grp_Member.iUSRid
        union all
        select Decode(NVL(ODB_Grp_Member_Spool.eid, -1),
                      -1,
                      'Spool',
                      'Register') va,
               ODB_Grp_Member_Spool.grp_id,
               USR.iUSRid,
               USR.cUSRlogname,
               USR.cUSRname,
               USR.dUSRfire
          from ODB_Grp_Member_Spool, USR
         where ODB_Grp_Member_Spool.grant_revoke = 'G'
           and USR.iUSRid = ODB_Grp_Member_Spool.iUSRid)
 where grp_id in
       (SELECT GROUP_ID
          FROM (select '' va,
                       MNC.iMNCmnb menu_id,
                       ODB_Group_Usr.grp_id group_id,
                       ODB_Group_Usr.grp_name group_name,
                       '' status
                  from MNC, ODB_Group_Usr
                 where ODB_Group_Usr.grp_id = MNC.idMNCgrp
                   and not exists
                 (select null
                          from MNC_Spool
                         where MNC_Spool.iMNCmnb = MNC.iMNCmnb
                           and MNC_Spool.idMNCgrp = MNC.idMNCgrp)
                union all
                select Decode(NVL(MNC_Spool.eid, -1), -1, 'Spool', 'Register') va,
                       MNC_Spool.iMNCmnb menu_id,
                       ODB_Group_Usr.grp_id group_id,
                       ODB_Group_Usr.grp_name group_name,
                       Decode(NVL(MNC_Spool.eid, -1),
                              -1,
                              '������ ������������ � �����������',
                              '������ ����������������') status
                  from MNC_Spool, ODB_Group_Usr
                 where MNC_Spool.grant_revoke = 'G'
                   and ODB_Group_Usr.grp_id = MNC_Spool.idMNCgrp)
         WHERE menu_id in
               (SELECT IMNBID
                  FROM MNB
                 where mnb.cmnbname = '�� �� ������������� ���������'));
*/
SELECT distinct /*a.GRP_NAME, b.GRP_ID,*/ c.CUSRNAME,
                c.CUSRLOGNAME,
                c.cusrdivision,
                c.IUSRBRANCH
  FROM ODB_GROUP_USR a, ODB_Grp_Member b, usr c
 where a.grp_id = b.grp_id
   and c.iusrid = b.iusrid
   and a.grp_id in
       (select IDMNCGRP
          from MNC t
         where t.IMNCMNB in
               (SELECT IMNBID
                  FROM MNB
                 where mnb.cmnbname = '�� �� ������������� ���������'))
   and c.dusrfire is null
   and IUSRBRANCH = 6
