with dat as
 (select rowid id_,
         ROW_NUMBER() OVER(PARTITION BY PAYMENTNUMBER ORDER BY t.PAYDATE) cnt,
         t.*
    from Z_SB_TRANSACT_DBT t)
select *
  from Z_SB_TRANSACT_DBT
 where rowid in (select id_ from dat where cnt > 1)
   for update
