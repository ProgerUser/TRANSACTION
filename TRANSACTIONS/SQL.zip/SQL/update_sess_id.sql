update (select p.trid, p.sess_id from_, t.sess_id
          from Z_SB_TRANSACT_DBT t,
               (select distinct TRID, sess_id from Z_SB_POSTDOC_DBT) p
         where t.trid = p.trid)
   set sess_id = from_;

update (select t.rowid, p.trid, p.sess_id from_, t.sess_id
          from Z_SB_TRANSACT_DBT t,
               (select distinct TRID, sess_id from Z_SB_POSTDOC_DBT) p
         where t.trid = p.trid)
   set sess_id = from_
   
   
   
   update Z_SB_TRANSACT_DBT t
      set t.sess_id =
          (select g.sess_id
             from (select TRID, max(sess_id) sess_id
                     from Z_SB_POSTDOC_DBT
                    group by TRID) g
            where g.TRID = t.trid)
            
    where t.trid = (select trid
                      from (select TRID, max(sess_id) sess_id
                              from Z_SB_POSTDOC_DBT
                             group by TRID) g
                     where g.TRID = t.trid)
            
    where trid =
          (select TRID
             from (select distinct TRID, sess_id from Z_SB_POSTDOC_DBT))


select p.trid, p.sess_id from_, t.sess_id
  from Z_SB_TRANSACT_DBT t,
       (select TRID, max(sess_id) from Z_SB_POSTDOC_DBT group by TRID) p
 where t.trid = p.trid

select t.*, ROW_NUMBER() OVER(PARTITION BY TRID ORDER BY TRID) cnt
  from (select distinct TRID, sess_id from Z_SB_POSTDOC_DBT) t
