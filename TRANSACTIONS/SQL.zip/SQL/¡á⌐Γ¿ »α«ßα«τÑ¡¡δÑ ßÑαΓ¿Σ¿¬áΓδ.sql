select *
  from (select row_number() over(partition by REQUESTER_NAME order by CERTIFICATE_EXPIRATION_DATE desc) rn,
               count(*) over(partition by REQUESTER_NAME) cn,
               t.*
          from (select request_id,
                       requester_name,
                       to_date(certificate_effective_date,
                               'dd.mm.yyyy hh24:mi:ss') certificate_effective_date,
                       to_date(certificate_expiration_date,
                               'dd.mm.yyyy hh24:mi:ss') certificate_expiration_date,
                       issued_organization_unit,
                       issued_common_name
                  from Z_SB_CERTS) t)
 where ((rn = cn) and (issued_organization_unit <> '�����'))
   and (certificate_expiration_date between
       to_date('01-01-2020', 'dd-mm-yyyy') and
       to_date('31-05-2020', 'dd-mm-yyyy'))
