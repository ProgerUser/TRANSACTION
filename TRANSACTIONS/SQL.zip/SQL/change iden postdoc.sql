select *
  from (select count(*) over(partition by account_payer, account_receiver, sum, sess_id, ground, pay_date) cnt,
               ROW_NUMBER() over(partition by account_payer, account_receiver, sum, sess_id, ground, pay_date order by account_payer, account_receiver, sum, ground) rn,
               rowid rd,
               t.*
          from Z_SB_POSTDOC_AMRA_DBT t)
 where cnt > 1;
/ 
declare 
in_ number := 0;
begin
  for r in (select *
              from (select count(*) over(partition by account_payer, account_receiver, sum, sess_id, ground, pay_date) cnt,
                           ROW_NUMBER() over(partition by account_payer, account_receiver, sum, sess_id, ground, pay_date order by account_payer, account_receiver, sum, ground) rn,
                           rowid rd,
                           t.*
                      from Z_SB_POSTDOC_AMRA_DBT t)
             where cnt > 1) loop
    in_ := in_ + 1;
    update Z_SB_POSTDOC_AMRA_DBT t
       set t.ground = in_ || r.ground
     where t.rowid = r.rd;
  end loop;
end;
