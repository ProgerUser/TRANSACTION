/* ��������� ������ ������ ��������� */
select a1.iAccOtd As iOtdNum,
       (Select cOtdName From Otd Where iOtdNum = a1.iAccOtd) As cOtdName,
       a1.iAccOtd OtdDeb,
       a2.iAccOtd OtdCred,
       iTrnPNum,
       iTrnBa2D,
       iTrnBa2C,
       decode(iTRNba2d, 30102, 0, 1) InOut_type_0,
       iTRNbatnum iTRNbatnum_0,
       cTRNidopen cTRNidopen_0,
       iTRNdocnum iTRNdocnum_0,
       cTRNaccd cTRNaccd_0,
       cTRNcur cTRNcur_0,
       cTRNcur cTRNcur4Group_0,
       mTRNsum mTRNsum_0,
       cTRNaccc cTRNaccc_0,
       cTRNcurc cTRNcurc_0,
       mTRNsumc mTRNsumc_0,
       mTRNrsum mTRNrsum_0,
       iTRNtype iTRNtype_0,
       A1.cACCcusban CusBanDeb_R,
       A2.cACCcusban CusBanCred_R,
       A1.cACCcusban CusBanDeb,
       A2.cACCcusban CusBanCred,
       (select Nvl(Decode(:P_SORT_PORTION,
                          'NOT',
                          0,
                          'ALL',
                          Nvl(Max(iPotPortion), 0),
                          Decode(iTrnBatNum, 1, Nvl(Max(iPotPortion), 0), 0)),
                   0)
          from Bnk, Pot, Dvr
         where iBnkId = iDvrBnkId
           and iPotId = iBnkPortionId
           and iDvrTrnNum = iTrnNum
           and iDvrTrnANum = iTrnANum) iPotPortion,
       iTrnNum,
       iTrnANum

  From Trn, Acc a1, Acc a2
 where dTrnTran between to_date(:P_Rep_Date, 'DD.MM.RRRR') and :CF_Date2
   and a1.cAccAcc = cTrnaccD
   and a1.cAccCur = cTrnCur
   and a2.cAccAcc = cTrnaccC
   and a2.cAccCur = cTrnCurC
   and ((((substr(trn.CTRNACCD, 1, 5) in
       ('20208',
          '70209',
          '20209',
          '30222',
          '30221',
          '47416',
          '47417',
          '47422',
          '47423',
          '47425',
          '60301',
          '60302',
          '60303',
          '60305',
          '60306',
          '60308',
          '60309',
          '60310',
          '60311',
          '60312',
          '60315',
          '60323',
          '60324',
          '60401',
          '60406',
          '60601',
          '60604',
          '60701',
          '60901',
          '60903',
          '61002',
          '61008',
          '61009',
          '61011',
          '61101',
          '61103',
          '61201',
          '61202',
          '61301',
          '61304',
          '61403')) and (substr(trn.CTRNACCC, 1, 5) not in ('61306')) and 
          (substr(trn.CTRNACCD, 1, 5) not in ('60305' )  and  substr(trn.CTRNACCC, 1, 3) not in ('408')) and
          (substr(trn.CTRNACCC, 1, 5) not in ('20202')) and 
          (substr(trn.CTRNACCD, 1, 5) not in ('61301' )  and substr(trn.CTRNACCC, 1, 5) not in ('70101')) ) 
          or ((substr(trn.CTRNACCC, 1, 5) in
       ('20208',
                         '70209',
                         '20209',
                         '30222',
                         '30221',
                         '47416',
                         '47417',
                         '47422',
                         '47423',
                         '47425',
                         '60301',
                         '60302',
                         '60303',
                         '60305',
                         '60306',
                         '60308',
                         '60309',
                         '60310',
                         '60311',
                         '60312',
                         '60315',
                         '60323',
                         '60324',
                         '60401',
                         '60406',
                         '60601',
                         '60604',
                         '60701',
                         '60901',
                         '60903',
                         '61002',
                         '61008',
                         '61009',
                         '61011',
                         '61101',
                         '61103',
                         '61201',
                         '61202',
                         '61301',
                         '61304',
                         '61403'))) and 
                         (substr(trn.CTRNACCD, 1, 5) not in ('61406')) and
                         (substr(trn.CTRNACCD, 1, 5) not in ('20202' )) and
                         (substr(trn.CTRNACCD, 1, 5) not in ('40912' , '40913') ) ) or
       ((substr(trn.CTRNACCD, 1, 2) = '91' or
       substr(trn.CTRNACCC, 1, 2) = '91') and
       (substr(trn.CTRNACCC, 1, 5) = '99999' or
       substr(trn.CTRNACCD, 1, 5) = '99999')) or
       (trn.ITRNTYPE = 20 and
       ((substr(trn.CTRNACCD, 1, 5) in ('30120', '30114')) or
       (substr(trn.CTRNACCC, 1, 5) in ('30114', '4')) or
       (substr(trn.CTRNACCD, 1, 3) in ('408', '407')) or
       (substr(trn.CTRNACCC, 1, 3) in ('408', '407')))or ((substr(trn.CTRNACCD, 1, 5) in ('30102') and
       substr(trn.CTRNACCC, 1, 5) in ('30102') ) and trn.CTRNIDOPEN in ('U176'))) or
       (trn.ITRNTYPE = 4 and (substr(trn.CTRNACCD, 1, 5) in ('40817') or
       substr(trn.CTRNACCD, 1, 5) in ('40810') or
       substr(trn.CTRNACCD, 1, 20) in ('60322810800000000006') or
       substr(trn.CTRNACCC, 1, 20) in ('60322810800000000006') or
       substr(trn.CTRNACCD, 1, 5) in ('40830') or     
       substr(trn.CTRNACCD, 1, 5) in ('47411') or 
      (substr(trn.CTRNACCD, 1, 5) in (60322) and (substr(trn.CTRNACCC, 1, 5) in ('30102') or substr(trn.CTRNACCC, 1, 5) in ('30120')))))
 or
       
       (
       trn.ITRNTYPE = 1 and ((substr(trn.CTRNACCD, 1, 5) in ('30102') and
       substr(trn.CTRNACCC, 1, 5) in ('30102'))    or (substr(trn.CTRNACCD, 1, 5) in ('40830') and
        substr(trn.CTRNACCC, 1, 5) in ('40830')) or (substr(trn.CTRNACCD, 1, 5) in ('40817') and
        substr(trn.CTRNACCC, 1, 5) in ('40817')) or (substr(trn.CTRNACCD, 1, 5) in ('40831') and
        substr(trn.CTRNACCC, 1, 5) in ('40831'))or (substr(trn.CTRNACCD, 1, 5) in ('30120') and
       substr(trn.CTRNACCC, 1, 5) in ('30102')) or
       substr(trn.CTRNACCD, 1, 20) in ('60322810800000000006') or
       substr(trn.CTRNACCC, 1, 20) in ('60322810800000000006') or
       (substr(trn.CTRNACCD, 1, 5) in ('30102') and  substr(trn.CTRNACCC, 1, 5) in ('60322')))
       ) or 
        (trn.ITRNTYPE = -1 and (substr(trn.CTRNACCD, 1, 5) in ('70202') and
       substr(trn.CTRNACCC, 1, 5) in ('40702')) and trn.CTRNIDOPEN in ('U176'))
       
       )
   and trn.CTRNIDOPEN in (
                          'U71',
                          'U22',
                          'U146',
                          'U27',
                          'U143',
                          'U35',
                          'U129',
                          'U141',
                          'U176',
                          'U140',
                          'U193',
                          'U191',
                          'U61',
                          'U64',
                          'U1015',
                          'U123',
                          'U75',
                          'U74',
                          'U126',
                          'U104',
                          'KADJAYA_O')
   and ((substr(trn.CTRNACCD, 1, 5) not in ('60305' )  and substr(trn.CTRNACCC, 1, 3) not in ('408')) and
  (substr(trn.CTRNACCD, 1, 5) not in ('61406')) and     
  (substr(trn.CTRNACCC, 1, 5) not in ('61306')) and
  (substr(trn.CTRNACCD, 1, 5) not in ('20202' )) or (substr(trn.CTRNACCC, 1, 5) not in ('20202')) and 
  (substr(trn.CTRNACCD, 1, 5) not in ('61301' )  and substr(trn.CTRNACCC, 1, 5) not in ('70101')))
