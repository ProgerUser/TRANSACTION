select *
  from (select count(*) over(partition by KBK) cnt,
               ROW_NUMBER() over(partition by KBK order by KBK) rn,
               t.*
          from SBRA_KBK t)
 where CNT > 1;
select * from cdt;
