select t.paydate data_inkass,
       t.amountofpayment summa_inkass,
       nvl((select sum(g.CASHAMOUNT)
             from Z_SB_TRANSACT_AMRA_DBT g
            where g.terminal = t.terminal
              and g.PAYDATE < t.paydate
              and g.PAYDATE > nvl((select max(k.PAYDATE)
                                    from Z_SB_TRANSACT_AMRA_INKAS k
                                   where k.paydate < t.paydate),
                                  ADD_MONTHS(t.paydate, -50))),
           0) summa_tranz,
       t.terminal,
       nvl((select max(k.PAYDATE)
             from Z_SB_TRANSACT_AMRA_INKAS k
            where k.paydate < t.paydate),
           ADD_MONTHS(t.paydate, -50)) minim,
           
           
  from Z_SB_TRANSACT_AMRA_INKAS t
 order by PAYDATE desc
