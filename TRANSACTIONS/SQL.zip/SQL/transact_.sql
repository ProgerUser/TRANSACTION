with dat as
 (select COLUMN1 TRID,
         COLUMN2,
         COLUMN3 PAYMENT_NUMBER,
         COLUMN4,
         COLUMN5,
         COLUMN6,
         COLUMN7,
         COLUMN8,
         COLUMN9,
         COLUMN10,
         COLUMN11,
         COLUMN12,
         COLUMN13,
         COLUMN14,
         COLUMN15,
         COLUMN16,
         COLUMN17,
         COLUMN18,
         to_date(COLUMN19, 'DD-MM-RRRR HH24:MI:SS') pay_date,
         COLUMN20,
         COLUMN21,
         COLUMN22,
         COLUMN23,
         COLUMN24,
         COLUMN25,
         COLUMN26,
         COLUMN27,
         COLUMN28,
         COLUMN29,
         COLUMN30,
         COLUMN31,
         COLUMN32,
         COLUMN33,
         COLUMN34,
         COLUMN35,
         COLUMN36,
         DATE_TIME,
         SESS_ID,
         FILE_NAME
    from z_sb_fn_sess s,
         table(lob2table.separatedcolumns(FILECLOB, /* the data LOB */
                                          chr(10), /* row separator */
                                          ';', /* column separator */
                                          '' /* delimiter (optional) */)) t
   where s.fileclob is not null
     and s.fileclob not like '%"UTF-8"?%'
     AND s.fileclob not like '%�?�?в�?р�?�?н%'
     AND S.FILE_NAME not like '%fecovery%'
     AND T.COLUMN19 <> '"19"'),
dat_gr as
 (select *
    from (select ROW_NUMBER() OVER(PARTITION BY TRID ORDER BY t.pay_date) cnt,
                 t.*
            from dat t
           where t.pay_date >
                 to_date('01.09.2010 14:18:18', 'dd.mm.yyyy hh24:mi:ss')
             and t.pay_date <
                 to_date('03.12.2019 3:13:39', 'dd.mm.yyyy hh24:mi:ss'))
   where (CNT = 1))
select *
  from dat_gr

/*
select *
  from Z_SB_TERMDEAL_DBT
 where PAYMENTNUMBER in (select payment_number from dat_gr)
*/

/*
SELECT *
 FROM Z_SB_TRANSACT_DBT t
where t.trid in (select t.TRID from dat_gr t)
*/

/*
where trid = '3563E647-020F-4BA1-81B1-73DBA9443D25'
*/
