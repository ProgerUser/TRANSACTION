create or replace type t_record as object (
  i number,
  n varchar2(30)
);
/
