--ORA-00001: unique constraint (XXI.P_AU_DATA) violated;


select * from dba_constraints t
where t.constraint_name = 'P_AU_DATA';

SELECT * FROM AU_SESSION
--where ID  = 916541
order by D_SESSION desc;

select * from AU_ACTION
where IACTION_ID = 46881635
