select *--IPLETRNNUM, IPLETRNANUM
  from pl_op_rec r, pl_msg_finans m, ple e
where ((r.imsgfinid = m.imsgfinid
   and r.ioprecid = e.ioprecid)
and
(dmsgtrndate = to_date('27-02-2020', 'dd-mm-yyyy')))
and
(cmsgcardnum = '9990080055263268')
