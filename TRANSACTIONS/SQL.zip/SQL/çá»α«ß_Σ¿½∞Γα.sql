( V_PLE.IPLESTATUS in (2, 3)
 and imdproctype = 9
 and exists (select 1
from trn
 where trn.itrnnum = v_ple.ipletrnnum
 and trn.ITRNANUM = v_ple.ipletrnanum
 and trn.dtrntran is not null)
 and (nvl(pl_card.get_cardparam(11, v_ple.IPLEPART), '0') in
 (Select Regexp_Substr(:p1, '[^,]+', 1, Level)
 From Dual
 Connect By Regexp_Substr(:p1, '[^,]+', 1, Level) Is Not Null) or
 :p1 = -1)
/*���������� ������*/
 and IPLEAGRID not in
 (select pl_ca.iplaagrid
from pl_ca,
 (select cda.ccdacurrentacc
from cda
 where cda.icdastatus = 2
 and ccdacurrentacc is not null
 and cda.ncdaagrid in /*999 - ������ ������*/
 (select q.ncdaagrid plc_acc
from cda_g w, cda q
 where w.ncdgagrid = q.ncdaagrid
 and w.ncdgcnum = 999
 and w.ncdggnum = 1) /*--------*/
union
select CADDACC ccdacurrentacc
from cda_acc, cda
 where substr(CADDACC, 1, 5) in
 ('40817', '40820', '40830', '40831')
 and cda.ncdaagrid = cda_acc.NADDAGRID
 and cda.icdastatus = 2
 and CADDACC is not null
 and cda.ncdaagrid in /*999 - ������ ������*/
 (select q.ncdaagrid plc_acc
from cda_g w, cda q
 where w.ncdgagrid = q.ncdaagrid
 and w.ncdgcnum = 999
 and w.ncdggnum = 1) /*--------*/
) b
 where pl_ca.iplscatype = 14
 and pl_ca.caccacc = b.ccdacurrentacc)
/*----------------*/
 and exists
 (select 1
from plc, pl_p, pl_ch
 where pl_p.iplpid = plc.iplpid
 and pl_ch.iplcid = plc.iplcid
 and iplchtype = 1
 and cplchval = '2'
 and pl_p.cplppackfile like
 decode(:p2, '700', '700', '%', '%', '<>700', '%')
 and pl_p.cplppackfile <> decode(:p2, '<>700', '700', '-1')
 and v_ple.IPLEAGRID = plc.iplaagrid)
 and (rownum < = :p3 or :p3 = -1))
