SELECT *
  FROM user_constraints uc, user_cons_columns ucc1, user_cons_columns ucc2
 WHERE uc.constraint_name = ucc1.constraint_name
   AND uc.r_constraint_name = ucc2.constraint_name
   AND ucc1.POSITION = ucc2.POSITION -- Correction for multiple column primary keys.
   AND uc.constraint_name = 'RK_PLE_OP_REC'
 ORDER BY ucc1.TABLE_NAME, uc.constraint_name;

PLE
