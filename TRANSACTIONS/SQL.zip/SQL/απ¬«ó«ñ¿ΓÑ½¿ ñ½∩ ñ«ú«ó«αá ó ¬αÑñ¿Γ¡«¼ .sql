select t.rowid, t.* from cdoffc t;
