with data as
 (select dt_connect,
         sum_proc,
         (nvl(REST_OSN_IN, 0) - nvl(REST_ACC_TECH_OVER_IN, 0) -
         nvl(DT_FROM_TRANSACT, 0) + nvl(KT_FROM_TRANSACT, 0)) sum_abs_out,
         sum_proc - (nvl(REST_OSN_IN, 0) - nvl(REST_ACC_TECH_OVER_IN, 0) -
         nvl(DT_FROM_TRANSACT, 0) + nvl(KT_FROM_TRANSACT, 0)) razn,
         (select plc.cplcnum from plc where plc.iplcid = plc_id_file) cplcnum,
         (select cus.ccusname
            from acc, cus
           where acc.iacccus = cus.icusnum
             and acc.caccacc = acc_osn
             and acc.cacccur = ACC_OSN_CUR) ccusname,
         acc_osn,
         acc_osn_cur,
         rest_osn_in,
         acc_tech_over,
         rest_acc_tech_over_in,
         nvl(rest_osn_in, 0) - nvl(rest_acc_tech_over_in, 0) rest_total_in,
         plc_id_file,
         DT_FROM_TRANSACT,
         KT_FROM_TRANSACT
  
    from (select
          
           dt_connect,
           sum_proc,
           acc_osn,
           acc_osn_cur,
           util_dm2.ACC_Ostt(0, acc_osn, acc_osn_cur, dt_connect, 'V', 1) rest_osn_in,
           acc_tech_over,
           util_dm2.ACC_Ostt(0,
                             acc_tech_over,
                             acc_tech_over_cur,
                             dt_connect,
                             'V',
                             1) rest_acc_tech_over_in,
           plc_id_file,
           -----------�� �������
           (SELECT sum(trn.mtrnsum)
              FROM trn
             WHERE trunc(trn.dtrntran) = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
               and trn.ctrnaccd = ACC_OSN
               and (itrnnum, itrnanum) in
                   (select IPLETRNNUM, IPLETRNANUM
                      from pl_op_rec r, pl_msg_finans m, ple e
                     where r.imsgfinid = m.imsgfinid
                       and r.ioprecid = e.ioprecid
                       and m.IFILEINID in
                           (select IFILEINID
                              from pl_file_in
                             where DFILEINLOAD = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
                            )
                    union
                    select IPLETRNNUM, IPLETRNANUM
                      from pl_op_rec_m r, pl_msg_merch m, ple_m e
                     where r.IMSGRECID = m.imsgfinid
                       and r.ioprecid = e.ioprecid
                       and m.IFILEINID in
                           (select IFILEINID
                              from pl_file_in
                             where DFILEINLOAD = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
                            )
                    union
                    select IPLETRNNUM, IPLETRNANUM
                      from pl_file_trn
                     where IFILEINID in
                           (select IFILEINID
                              from pl_file_in
                             where DFILEINLOAD = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
                            ))) dt_from_transact,
           -----------�� �������
           -----------�� �������  
           (SELECT sum(trn.mtrnsumc)
              FROM trn
             WHERE trunc(trn.dtrntran) = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
               and trn.ctrnaccc = ACC_OSN
               and (itrnnum, itrnanum) in
                   (select IPLETRNNUM, IPLETRNANUM
                      from pl_op_rec r, pl_msg_finans m, ple e
                     where r.imsgfinid = m.imsgfinid
                       and r.ioprecid = e.ioprecid
                       and m.IFILEINID in
                           (select IFILEINID
                              from pl_file_in
                             where DFILEINLOAD = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
                            )
                    union
                    select IPLETRNNUM, IPLETRNANUM
                      from pl_op_rec_m r, pl_msg_merch m, ple_m e
                     where r.IMSGRECID = m.imsgfinid
                       and r.ioprecid = e.ioprecid
                       and m.IFILEINID in
                           (select IFILEINID
                              from pl_file_in
                             where DFILEINLOAD = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
                            )
                    union
                    select IPLETRNNUM, IPLETRNANUM
                      from pl_file_trn
                     where IFILEINID in
                           (select IFILEINID
                              from pl_file_in
                             where DFILEINLOAD = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
                            ))) kt_from_transact
          -----------�� ������� 
            from (select ik_load_check_plc_rest.dt_connect,
                         ik_load_check_plc_rest.sum_rest sum_proc,
                         ik_load_check_plc_rest.cplcnum plc_id_file,
                         (select distinct pl_ca.caccacc
                            from plc, pl_ca
                           where plc.iplcid = ik_load_check_plc_rest.cplcnum
                             and pl_ca.iplaagrid = plc.iplaagrid
                             and pl_ca.iplscatype = 14) acc_osn,
                         (select distinct pl_ca.cacccur
                            from plc, pl_ca
                           where plc.iplcid = ik_load_check_plc_rest.cplcnum
                             and pl_ca.iplaagrid = plc.iplaagrid
                             and pl_ca.iplscatype = 14) acc_osn_cur,
                         
                         (select distinct pl_ca.caccacc
                            from plc, pl_ca
                           where plc.iplcid = ik_load_check_plc_rest.cplcnum
                             and pl_ca.iplaagrid = plc.iplaagrid
                             and pl_ca.iplscatype = 74) acc_tech_over,
                         (select distinct pl_ca.cacccur
                            from plc, pl_ca
                           where plc.iplcid = ik_load_check_plc_rest.cplcnum
                             and pl_ca.iplaagrid = plc.iplaagrid
                             and pl_ca.iplscatype = 14) acc_tech_over_cur
                    from ik_load_check_plc_rest
                   where dt_connect = to_date(&dt1, 'DD.MM.RRRR'))
           where dt_connect = to_date(&dt1, 'DD.MM.RRRR') /*'04.12.2017'*/
          )
   where (nvl(SUM_PROC, 0) <>
         nvl(REST_OSN_IN, 0) - nvl(REST_ACC_TECH_OVER_IN, 0) -
         nvl(DT_FROM_TRANSACT, 0) + nvl(KT_FROM_TRANSACT, 0))
     and &raz = 1
     and &full = 0
     and &footer_only = 0
      or (nvl(SUM_PROC, 0) = nvl(SUM_PROC, 0))
     and &raz = 0
     and &full = 1
     and &footer_only = 0
      or (nvl(SUM_PROC, 0) <> nvl(SUM_PROC, 0))
     and &raz = 0
     and &full = 0
     and &footer_only = 1)
select 
