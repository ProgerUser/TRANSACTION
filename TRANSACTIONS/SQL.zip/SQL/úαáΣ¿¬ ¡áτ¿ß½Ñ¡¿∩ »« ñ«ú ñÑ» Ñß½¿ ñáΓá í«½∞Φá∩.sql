select * from V_DJ_GRF t where iqdpdogid = 1663;
select count(*), IQDPDOGID from V_DJ_GRF t group by IQDPDOGID;
select IQDGNCHDAY, g.iqd4daysinterval, g.iqd4freeprc, IQD4DOGID, t.*, g.*
  from qdg t, qd4 g
 where (g.IQD4DOGID = t.iQdgIdent)
   and (iqdgnum = '42307810100000000202');
select * from qdg t where iqdgident = 1662
