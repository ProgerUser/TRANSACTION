/*PROMPT "FXbicomp.jar" -> 6.00/00_129_KERNEL#22
EXEC UTIL_FRM.Register ('FXBICOMP.JAR', '6.00/00_129_KERNEL#22')
COMMIT COMMENT '6.00/00_129_KERNEL#22';*/

select t.rowid, t.* from FRM_VERSION t where cform = 'FXAUD.JAR';

update FRM_VERSION set CVERSION = '6.00/00_156_KERNEL#27' where cform = 'JINVDESKTOPADMIN.JAR';
