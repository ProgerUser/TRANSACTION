select max(DAUDDATE) DAUDDATE, cauduser
  from AU_ACTION t
 where ctable like 'XXI_LOGON'
   and cauduser in (select CUSRLOGNAME from usr where DUSRFIRE is null)
 group by cauduser
 order by DAUDDATE asc
