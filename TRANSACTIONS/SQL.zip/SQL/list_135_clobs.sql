select * from NOR2S t
where cnorsname in ('104','104_1')
for update
