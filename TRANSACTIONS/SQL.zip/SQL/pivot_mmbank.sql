with dat as
 (select ROW_NO, replace(COLUMN1, ' ', '') cell, COLUMN2 val
    from table(lob2table.separatedcolumns((select TEXT from Z_SB_TEST), /* the data LOB */
                                          chr(10), /* row separator */
                                          '=', /* column separator */
                                          '' /* delimiter (optional) */))),
dat2 as
 (select row_number() over(partition by CELL order by ROW_NO) cnt,
         rownum rn,
         t.*
    from dat t
   where cell in ('MFO_PLAT',
                  'KS_PLAT',
                  'BANK_PLAT',
                  'NDOC',
                  'CODE',
                  'PRIOR',
                  'PLAT_OKPO',
                  'CENTER_REC',
                  'PrintMode',
                  'MFO_REC',
                  'KS_REC',
                  'ACC_REC',
                  'INN',
                  'NAME_REC',
                  'BANK_REC',
                  'CITY_REC',
                  'NOTEBENE',
                  'DATE_DOC',
                  'DATE',
                  'ExecDATE',
                  'TYPE',
                  'NAME_PLAT',
                  'INN_PLAT',
                  'ACC_PLAT',
                  'SUM',
                  'PLAT_TYPE',
                  'KPP_REC',
                  'KPP_PLAT',
                  'TYPE_DOC')
   order by ROW_NO)

select *
  from dat2

PIVOT ( min(ROW_NO)/*stragg(val\*, ','*\) within group(order by null)*/
       FOR cell IN('MFO_PLAT' "MFO_PLAT",
             'KS_PLAT' "KS_PLAT",
             'BANK_PLAT' "BANK_PLAT",
             'NDOC' "NDOC",
             'CODE' "CODE",
             'PRIOR' "PRIOR",
             'PLAT_OKPO' "PLAT_OKPO",
             'CENTER_REC' "CENTER_REC",
             'PrintMode' "PrintMode",
             'MFO_REC' "MFO_REC",
             'KS_REC' "KS_REC",
             'ACC_REC' "ACC_REC",
             'INN' "INN",
             'NAME_REC' "NAME_REC",
             'BANK_REC' "BANK_REC",
             'CITY_REC' "CITY_REC",
             'NOTEBENE' "NOTEBENE",
             'DATE_DOC' "DATE_DOC",
             'DATE' "DATE",
             'ExecDATE' "ExecDATE",
             'TYPE' "TYPE",
             'NAME_PLAT' "NAME_PLAT",
             'INN_PLAT' "INN_PLAT",
             'ACC_PLAT' "ACC_PLAT",
             'SUM' "SUM",
             'PLAT_TYPE' "PLAT_TYPE",
             'KPP_REC' "KPP_REC",
             'KPP_PLAT' "KPP_PLAT",
             'TYPE_DOC' "TYPE_DOC"))
