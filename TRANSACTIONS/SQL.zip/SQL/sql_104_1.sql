select CARG,
       CACC,
       ICUS,
       CCUSNAME,
       BS2,
       MREPA,
       MREPPA,
       (MREPA + MREPPA) / 1000 summ_1000
  from (Select B.ncdvagrid cArg,
               cdterms.get_DogACC(B.nCDVagrid, 6) cAcc,
               B.ICDVCLIENT iCus,
               s.ccusname,
               substr(cdterms.get_DogACC(B.nCDVagrid, 6), 1, 5) BS2,
               RATES.Cur_Rate_New(B.CCDVCURISO,
                                  (to_date(&p16, 'dd.mm.yyyy') - 1)) *
               to_char(nvl(CDBALANCE.get_CurSaldo(B.NCDVAGRID,
                                                  6,
                                                  null,
                                                  null,
                                                  (to_date(&p16, 'dd.mm.yyyy') - 1)),
                           0)) mRePA, /*������������ ��������*/
               0 mRePpA
          from Fil_On2 F, cdv B, cda A, cus s
         Where A.idSmr = F.idSMR
           and s.icusnum = B.ICDVCLIENT
           and F.iSMRfil = Decode(-1, -1, F.iSMRfil, -1)
           and B.ncdvagrid = A.ncdaagrid
           and (to_date(&p16, 'dd.mm.yyyy') - 1) -
               greatest(B.DCDVENDDATE,
                        (select nvl(max(DCDEDATE),
                                    to_date('01.01.1900', 'dd.mm.yyyy'))
                           from cde e
                          where e.NCDEAGRID = a.NCDAAGRID
                            and e.icdetype in (2, 3, 12, 13, 72, 113, 172))) > 1095
           and substr(cdterms.get_DogACC(B.nCDVagrid, 6), 1, 5) != 45918 /*��������� ������.����*/
        union all
        Select B.ncdvagrid cArg,
               cdterms.get_DogACC(B.nCDVagrid, 101) cAcc,
               B.ICDVCLIENT iCus,
               s.ccusname,
               substr(cdterms.get_DogACC(B.nCDVagrid, 101), 1, 5) BS2,
               0 mRePA,
               RATES.Cur_Rate_New(B.CCDVCURISO,
                                  (to_date(&p16, 'dd.mm.yyyy') - 1)) *
               to_char(nvl(CDBALANCE.get_CurSaldo(B.NCDVAGRID,
                                                  101,
                                                  null,
                                                  null,
                                                  (to_date(&p16, 'dd.mm.yyyy') - 1)),
                           0)) mRePpA /*�������� �� ������������ ��������*/
          from Fil_On2 F, cdv B, cda A, cus s
         Where A.idSmr = F.idSMR
           and s.icusnum = B.ICDVCLIENT
           and F.iSMRfil = Decode(-1, -1, F.iSMRfil, -1)
           and B.ncdvagrid = A.ncdaagrid
           and (to_date(&p16, 'dd.mm.yyyy') - 1) -
               greatest(B.DCDVENDDATE,
                        (select nvl(max(DCDEDATE),
                                    to_date('01.01.1900', 'dd.mm.yyyy'))
                           from cde e
                          where e.NCDEAGRID = a.NCDAAGRID
                            and e.icdetype in (2, 3, 12, 13, 72, 113, 172))) > 1095
           and substr(cdterms.get_DogACC(B.nCDVagrid, 101), 1, 5) != 45918)
 where (MREPA + MREPPA) != 0
