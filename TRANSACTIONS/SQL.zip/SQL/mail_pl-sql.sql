begin
  mail_client.connect_server(p_hostname => 'imap.yandex.ru',
                             p_port     => 993,
                             p_protocol => mail_client.PROTOCOL_IMAP,
                             p_userid   => 'itsbra@yandex.ru',
                             p_passwd   => 'cjktyysq098',
                             p_ssl      => false);
  dbms_output.put_line('Connected to ^MAILSERV.:^MAILPORT using the ^MAILPROT. protocol.');
  mail_client.open_inbox;
  dbms_output.put_line('Mailbox successfully opened.');
  dbms_output.put_line('The INBOX folder contains ' ||
                       mail_client.get_message_count || ' messages.');
end;
